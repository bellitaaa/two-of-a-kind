/**
 * TWO OF A KIND · free back end for the invitation website.
 *
 * Where this goes: your RSVP Google Sheet → Extensions → Apps Script → paste this whole file.
 * Then: set HOST_PASSWORD below, save, and Deploy → New deployment → Web app
 *       (Execute as: Me · Who has access: Anyone). Copy the Web app URL into the website's config.js.
 *
 * It keeps the guest list in this spreadsheet, logs every reply in the "Responses" tab,
 * hides the Airbnb address until a guest confirms, and emails you (from your Gmail) for each reply.
 */

// ───────────────────────────────────────── 1. Your settings
var HOST_PASSWORD = 'CHANGE-ME'; // the password for your dashboard: at least 8 characters

// ───────────────────────────────────────── 2. Nothing below needs changing

var DEFAULT_SETTINGS = {
  eventName: 'Two of a Kind',
  hostName: '',
  tagline: 'A Birthday Celebration',
  celebrants: '',
  date: '2026-11-21',
  time: '13:00',
  endTime: '',
  timezone: 'Africa/Kampala',
  venue: 'Private Airbnb',
  area: '',
  address: '',
  mapsUrl: '',
  rsvpDeadline: '',
  allowLate: false,
  hideAddress: true,
  openInvite: true,
  openMaxParty: 1,
  defaultMaxParty: 1,
  capacity: 0,
  musicUrl: '',
  notifyEmail: '', // blank = the Google account that owns this script
  notifyOnRsvp: true,
  pushTopic: '',
  pushOnRsvp: true,
  moodboard: [
    { src: '', caption: 'the flowers', note: 'blooms for the birthday girls' },
    { src: '', caption: 'candlelight', note: 'candles lit, music on' },
    { src: '', caption: 'cheers to us', note: 'food & drinks sorted' },
    { src: '', caption: 'game night', note: 'winner picks the next song' },
  ],
  amp: { text: '&', x: 50, y: 47, size: 26, color: 'canvas', show: true },
  texts: {
    linerScript: 'cheers to the twins',
    tape: 'for {name} ♡',
    kicker: 'Please join us to celebrate',
    byobTitle: 'UGX 150,000',
    byobText: 'Per person. Covers food, drinks & all the fun.',
    byobBack: 'Send it by Mobile Money to any of Asherbell’s numbers ♡',
    gamesTitle: 'Got games?',
    gamesText: 'Bring your favourites along!',
    gamesBack: 'Cards, board games, anything that gets everyone laughing.',
    comfyTitle: 'Come comfortable',
    comfyText: 'No dress code. Just good vibes.',
    comfyBack: 'Sneakers, sundress or sweats. You do you.',
  },
};
// Your saved look from the preview: wording, photos and the "&". Changes made later in Edit mode or the dashboard still win.
(function (look) { Object.keys(look).forEach(function (k) { DEFAULT_SETTINGS[k] = look[k]; }); })({
 "eventName": "Two of a Kind",
 "tagline": "Asher & Asherbell's",
 "celebrants": "Birthday Celebration",
 "texts": {
  "linerScript": "Cheers to the twins",
  "tape": "for {name} ♡",
  "kicker": "Please join us to celebrate",
  "byobTitle": "UGX 150,000",
  "byobText": "Per person. Covers food, drinks & all the fun.",
  "byobBack": "Send it by Mobile Money to any of Asherbell’s numbers ♡",
  "gamesTitle": "Got games?",
  "gamesText": "Bring your favourites along!",
  "gamesBack": "Cards, board games, anything that gets everyone laughing.",
  "comfyTitle": "Come comfortable",
  "comfyText": "No dress code. Just good vibes.",
  "comfyBack": "Sneakers, sundress or sweats. You do you."
 },
 "amp": {
  "text": "&",
  "x": 49.8,
  "y": 58.8,
  "size": 16.7,
  "color": "burgundy",
  "show": true
 },
 "moodboard": [
  {
   "src": "photos/photo-1.jpg",
   "caption": "Asher",
   "note": "blooms for the birthday girls"
  },
  {
   "src": "photos/photo-2.jpg",
   "caption": "Asherbell",
   "note": "candles lit, music on"
  },
  {
   "src": "",
   "caption": "cheers to us",
   "note": "food & drinks sorted"
  },
  {
   "src": "",
   "caption": "game night",
   "note": "winner picks the next song"
  }
 ]
});

// Never sent to guests unless they are allowed to see them.
var PRIVATE_KEYS = ['address', 'mapsUrl', 'notifyEmail', 'notifyOnRsvp', 'pushTopic', 'pushOnRsvp', 'capacity'];

var SHEET = { responses: 'Responses', guests: 'Guests', settings: 'Settings' };
var RESPONSE_HEADERS = ['Time', 'Name', 'Response', 'Party size', 'Contact', 'Bringing', 'Note', 'New or updated'];
var GUEST_COLS = [
  ['name', 'Name'], ['status', 'Status'], ['partySize', 'Party size'], ['contact', 'Contact'], ['game', 'Bringing'],
  ['message', 'Note'], ['respondedAt', 'Replied'], ['hostNote', 'Your note'], ['maxParty', 'Max party'], ['source', 'Came from'],
  ['createdAt', 'Added'], ['openedAt', 'First opened'], ['remindedAt', 'Reminded'], ['bringingGame', 'Bringing a game?'],
  ['token', 'Private link code'], ['contactNorm', 'Contact key'], ['lastRequestId', 'Request id'], ['id', 'Id'],
];
var STATUS_LABEL = { attending: 'Coming', declined: 'Can’t make it', pending: 'Pending' };

// ───────────────────────────────────────── web entry points
function doGet(e) { return respond_((e && e.parameter) || {}); }

function doPost(e) {
  var body;
  try { body = JSON.parse((e && e.postData && e.postData.contents) || '{}'); } catch (x) { return out_({ error: 'That request could not be read.', status: 400 }); }
  return respond_(body || {});
}

function respond_(p) {
  try {
    return out_(route_(p));
  } catch (err) {
    if (err && err.httpStatus) return out_({ error: err.message, status: err.httpStatus, code: err.code || '', fields: err.fields || null });
    console.error(err && err.stack ? err.stack : err);
    return out_({ error: 'Something went wrong on our side. Please try again.', status: 500 });
  }
}

function out_(obj) {
  if (!('status' in obj)) obj.status = 200;
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function fail_(status, message, code, fields) {
  var e = new Error(message);
  e.httpStatus = status; e.code = code; e.fields = fields;
  throw e;
}

function route_(p) {
  var a = String(p.action || 'invite');
  if (a === 'invite') return actionInvite_(p);
  if (a === 'rsvp') return actionRsvp_(p);
  var host = {
    hostState: function () { return hostState_(); },
    saveSettings: actionSaveSettings_, addGuests: actionAddGuests_, updateGuest: actionUpdateGuest_,
    deleteGuest: actionDeleteGuest_, newToken: actionNewToken_, upload: actionUpload_, remind: actionRemind_,
    testNotify: actionTestNotify_,
  }[a];
  if (!host) fail_(404, 'Unknown request.');
  checkHost_(p.password);
  return host(p);
}

// ───────────────────────────────────────── host sign-in
function checkHost_(pw) {
  if (!HOST_PASSWORD || HOST_PASSWORD === 'CHANGE-ME' || HOST_PASSWORD.length < 8) {
    fail_(503, 'Set HOST_PASSWORD at the top of the Apps Script (8+ characters), save, and deploy a new version.', 'setup');
  }
  var cache = CacheService.getScriptCache();
  var tries = Number(cache.get('host_fail') || 0);
  if (tries >= 15) fail_(429, 'Too many wrong passwords. Try again in 15 minutes.', 'locked');
  if (String(pw || '') !== HOST_PASSWORD) {
    cache.put('host_fail', String(tries + 1), 900);
    fail_(401, 'That password isn’t right.', 'auth');
  }
}

// ───────────────────────────────────────── spreadsheet storage
function ss_() { return SpreadsheetApp.getActiveSpreadsheet(); }

function sheet_(name, headers, textCols) {
  var ss = ss_();
  var sh = ss.getSheetByName(name);
  if (!sh) {
    var sheets = ss.getSheets();
    // Reuse the blank first tab of a brand-new spreadsheet for Responses.
    if (name === SHEET.responses && sheets.length === 1 && sheets[0].getLastRow() === 0 && /^(Sheet|Feuille|Hoja|Blatt)?\s*1$/i.test(sheets[0].getName())) {
      sh = sheets[0];
      sh.setName(name);
    } else {
      sh = ss.insertSheet(name);
    }
  }
  if (sh.getLastRow() === 0) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function asText_(v) {
  if (v === null || v === undefined) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') return isNaN(v) ? '' : v.toISOString();
  return String(v);
}

// Write a row of text values (formatted as plain text first so Sheets keeps leading zeros and "+").
function writeRow_(sh, row, values) {
  var r = sh.getRange(row, 1, 1, values.length);
  r.setNumberFormat('@');
  r.setValues([values.map(asText_)]);
}

function readSettings_() {
  var s = JSON.parse(JSON.stringify(DEFAULT_SETTINGS));
  var sh = sheet_(SHEET.settings, ['Setting', 'Value (managed by the dashboard)']);
  var rows = sh.getDataRange().getValues();
  for (var i = 1; i < rows.length; i++) {
    var k = String(rows[i][0] || '');
    if (!(k in DEFAULT_SETTINGS)) continue;
    try {
      var v = JSON.parse(String(rows[i][1]));
      s[k] = (k === 'texts' || k === 'amp') ? merge_(DEFAULT_SETTINGS[k], v) : v;
    } catch (x) { /* keep default */ }
  }
  return s;
}

function merge_(a, b) {
  var o = {}, k;
  for (k in a) o[k] = a[k];
  if (b && typeof b === 'object') for (k in b) o[k] = b[k];
  return o;
}

function writeSettings_(patch) {
  var sh = sheet_(SHEET.settings, ['Setting', 'Value (managed by the dashboard)']);
  var rows = sh.getDataRange().getValues();
  var at = {};
  for (var i = 1; i < rows.length; i++) at[String(rows[i][0])] = i + 1;
  Object.keys(patch).forEach(function (k) {
    var row = at[k] || Math.max(sh.getLastRow(), 1) + 1;
    at[k] = row;
    writeRow_(sh, row, [k, JSON.stringify(patch[k])]);
  });
}

function guestSheet_() { return sheet_(SHEET.guests, GUEST_COLS.map(function (c) { return c[1]; })); }

function readGuests_() {
  var sh = guestSheet_();
  var rows = sh.getDataRange().getValues();
  var out = [];
  for (var i = 1; i < rows.length; i++) {
    if (!rows[i].join('')) continue;
    var g = { _row: i + 1 };
    GUEST_COLS.forEach(function (c, j) { g[c[0]] = asText_(rows[i][j]); });
    var st = g.status;
    g.status = st === STATUS_LABEL.attending ? 'attending' : st === STATUS_LABEL.declined ? 'declined' : 'pending';
    g.partySize = parseInt(g.partySize, 10) || 0;
    g.maxParty = parseInt(g.maxParty, 10) || 1;
    g.bringingGame = g.bringingGame === 'yes';
    out.push(g);
  }
  return out;
}

function writeGuest_(g) {
  var sh = guestSheet_();
  var row = g._row || Math.max(sh.getLastRow(), 1) + 1;
  g._row = row;
  writeRow_(sh, row, GUEST_COLS.map(function (c) {
    var v = g[c[0]];
    if (c[0] === 'status') return STATUS_LABEL[v] || STATUS_LABEL.pending;
    if (c[0] === 'bringingGame') return v ? 'yes' : '';
    if (c[0] === 'partySize') return g.status === 'attending' ? String(v || 1) : '';
    return v === undefined || v === null ? '' : v;
  }));
}

function newGuest_(fields) {
  var t = new Date().toISOString();
  return merge_({
    id: Utilities.getUuid().slice(0, 8), token: newToken_(), name: '', contact: '', contactNorm: '', maxParty: 1, status: 'pending',
    partySize: 0, bringingGame: false, game: '', message: '', hostNote: '', source: 'invite', lastRequestId: '',
    createdAt: t, respondedAt: '', openedAt: '', remindedAt: '',
  }, fields);
}

function newToken_() { return Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '').slice(0, 6); }

function logResponse_(g, isUpdate, test) {
  var sh = sheet_(SHEET.responses, RESPONSE_HEADERS);
  var row = Math.max(sh.getLastRow(), 1) + 1;
  var vals = [new Date(), g.name, STATUS_LABEL[g.status] || g.status, g.status === 'attending' ? g.partySize : '',
    g.contact || '', g.status === 'attending' && g.bringingGame ? (g.game || 'a game') : '', g.message || '',
    test ? 'test' : isUpdate ? 'updated' : 'new'];
  sh.getRange(row, 5, 1, 1).setNumberFormat('@');
  sh.getRange(row, 1, 1, vals.length).setValues([vals]);
}

function withLock_(fn) {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(20000)) fail_(503, 'The invitation is busy right now. Please try again in a moment.');
  try { return fn(); } finally { lock.releaseLock(); }
}

// ───────────────────────────────────────── helpers
function cleanText_(v, max) {
  return String(v === undefined || v === null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, max);
}

function parseContact_(raw) {
  var value = String(raw || '').trim();
  if (!value) return { kind: null, value: '', norm: '' };
  if (value.indexOf('@') > -1) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value) ? { kind: 'email', value: value, norm: value.toLowerCase() } : { kind: 'invalid', value: value, norm: '' };
  }
  var digits = value.replace(/[^\d]/g, '');
  if (/^[+\d][\d\s().-]*$/.test(value) && digits.length >= 7 && digits.length <= 15) return { kind: 'phone', value: value, norm: 'p:' + digits.slice(-9) };
  return { kind: 'invalid', value: value, norm: '' };
}

function tzOffsetMs_(utcMs, tz) {
  var s = Utilities.formatDate(new Date(utcMs), tz, "yyyy-MM-dd'T'HH:mm:ss");
  var p = s.split(/[-T:]/).map(Number);
  return Date.UTC(p[0], p[1] - 1, p[2], p[3], p[4], p[5]) - utcMs;
}

function zonedToUtc_(date, time, tz) {
  var d = date.split('-').map(Number), t = (time || '00:00').split(':').map(Number);
  var guess = Date.UTC(d[0], d[1] - 1, d[2], t[0], t[1]);
  var off = tzOffsetMs_(guess, tz);
  var utc = guess - off;
  var off2 = tzOffsetMs_(utc, tz);
  return off2 === off ? utc : guess - off2;
}

function rsvpOpen_(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s.rsvpDeadline || '') || s.allowLate) return true;
  return Date.now() <= zonedToUtc_(s.rsvpDeadline, '23:59', s.timezone || 'UTC') + 59000;
}

function deadlineLabel_(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s.rsvpDeadline || '')) return '';
  var p = s.rsvpDeadline.split('-').map(Number);
  return Utilities.formatDate(new Date(Date.UTC(p[0], p[1] - 1, p[2], 12)), 'UTC', 'EEEE d MMMM');
}

function ownerEmail_() {
  try { return Session.getEffectiveUser().getEmail() || ''; } catch (x) { return ''; }
}

// What a guest's page may see. The full address only leaves here for confirmed guests.
function publicPayload_(s, g, mode) {
  var pub = {};
  Object.keys(s).forEach(function (k) { if (PRIVATE_KEYS.indexOf(k) === -1) pub[k] = s[k]; });
  if (!s.hideAddress || (g && g.status === 'attending')) { pub.address = s.address; pub.mapsUrl = s.mapsUrl; }
  pub.rsvpOpenNow = rsvpOpen_(s);
  return {
    mode: mode,
    token: g ? g.token : null,
    settings: pub,
    guest: g ? {
      name: g.name, contact: g.contact, status: g.status, party_size: g.partySize, max_party: g.maxParty,
      bringing_game: g.bringingGame ? 1 : 0, game: g.game, message: g.message, responded_at: g.respondedAt || null,
    } : null,
  };
}

// ───────────────────────────────────────── guest actions
function actionInvite_(p) {
  var s = readSettings_();
  var token = cleanText_(p.g || p.token, 80);
  if (!token) return publicPayload_(s, null, s.openInvite ? 'open' : 'closed');
  var g = null;
  readGuests_().forEach(function (x) { if (x.token === token) g = x; });
  if (!g) return publicPayload_(s, null, 'invalid');
  if (!g.openedAt) {
    try { withLock_(function () { g.openedAt = new Date().toISOString(); writeGuest_(g); }); } catch (x) { /* not important */ }
  }
  return publicPayload_(s, g, 'personal');
}

function actionRsvp_(b) {
  if (typeof b.attending !== 'boolean') fail_(400, 'Choose whether you can make it.');
  var s = readSettings_();
  var requestId = cleanText_(b.requestId, 64);
  var errors = {};
  var name = cleanText_(b.name, 80);
  if (name.length < 2) errors.name = 'Please add your name.';
  var contact = parseContact_(cleanText_(b.contact, 120));
  if (b.attending && !contact.kind) errors.contact = 'Add a phone number or email so we can reach you.';
  else if (contact.kind === 'invalid') errors.contact = 'That doesn’t look like a phone number or email.';
  var bringingGame = b.attending && b.bringingGame === true;
  var game = bringingGame ? cleanText_(b.game, 60) : '';
  var message = cleanText_(b.message, 280);

  return withLock_(function () {
    var guests = readGuests_();
    var g = null, isUpdate = false;
    if (b.token) {
      guests.forEach(function (x) { if (x.token === String(b.token)) g = x; });
      if (!g) fail_(404, 'This invitation link isn’t valid anymore. Ask the hosts for a fresh one.', 'invalid_token');
      if (requestId && g.lastRequestId === requestId) return publicPayload_(s, g, 'personal');
    } else {
      if (!s.openInvite) fail_(403, 'RSVPs here are by personal invitation. Ask the hosts for your link.', 'closed');
      if (requestId) {
        var prior = null;
        guests.forEach(function (x) { if (x.lastRequestId === requestId) prior = x; });
        if (prior) return publicPayload_(s, prior, 'personal');
      }
    }
    if (!rsvpOpen_(s)) fail_(403, 'RSVPs closed on ' + deadlineLabel_(s) + '. Message the hosts if your plans have changed.', 'deadline');

    var maxParty = g ? g.maxParty : s.openMaxParty;
    var partySize = 0;
    if (b.attending) {
      partySize = b.partySize === undefined ? 1 : Number(b.partySize);
      if (!(partySize >= 1 && partySize <= maxParty && Math.floor(partySize) === partySize)) {
        errors.partySize = maxParty === 1 ? 'This invitation is just for you.' : 'You can bring up to ' + (maxParty - 1) + ' guest' + (maxParty > 2 ? 's' : '') + '.';
      }
    }
    if (Object.keys(errors).length) fail_(422, 'A couple of things need a look.', 'fields', errors);

    if (!g && contact.norm) {
      guests.forEach(function (x) { if (x.contactNorm && x.contactNorm === contact.norm) g = g || x; });
      if (g) fail_(409, 'Looks like that number or email already has an RSVP. Use the private link on your guest pass to change it, or message the hosts.', 'duplicate');
    }
    if (b.attending && s.capacity > 0) {
      var heads = 0;
      guests.forEach(function (x) { if (x.status === 'attending' && (!g || x.id !== g.id)) heads += x.partySize; });
      if (heads + partySize > s.capacity) fail_(409, 'We’re at full capacity, so sorry! Message the hosts and we’ll see what we can do.', 'capacity');
    }
    if (!g) g = newGuest_({ name: name, contact: contact.value, contactNorm: contact.norm, maxParty: maxParty, source: 'shared link' });
    else isUpdate = g.status !== 'pending';

    g.name = name;
    g.status = b.attending ? 'attending' : 'declined';
    g.partySize = partySize;
    g.bringingGame = bringingGame;
    g.game = game;
    g.message = message;
    g.lastRequestId = requestId;
    g.respondedAt = new Date().toISOString();
    if (contact.kind) { g.contact = contact.value; g.contactNorm = contact.norm; }
    writeGuest_(g);
    logResponse_(g, isUpdate);
    notifyHost_(s, g, isUpdate, guests);
    return publicPayload_(s, g, 'personal');
  });
}

// ───────────────────────────────────────── notifications
function notifyStatus_(channel, ok, error) {
  var props = PropertiesService.getScriptProperties();
  var all = {};
  try { all = JSON.parse(props.getProperty('notifyStatus') || '{}'); } catch (x) { all = {}; }
  all[channel] = { at: new Date().toISOString(), ok: ok, error: error || '' };
  props.setProperty('notifyStatus', JSON.stringify(all));
}

function totals_(guests) {
  var c = 0, d = 0, e = 0;
  guests.forEach(function (x) { if (x.status === 'attending') { c++; e += x.partySize; } else if (x.status === 'declined') d++; });
  return c + ' confirmed · ' + e + ' people expected · ' + d + ' declined';
}

function notifyHost_(s, g, isUpdate, guestsBefore) {
  var guests = guestsBefore.filter(function (x) { return x.id !== g.id; }).concat([g]);
  var yes = g.status === 'attending';
  var headline = yes ? g.name + ' is in' + (g.partySize > 1 ? ' (party of ' + g.partySize + ')' : '') : g.name + ' can’t make it';
  var lines = [
    g.contact ? 'Contact: ' + g.contact : '',
    yes && g.bringingGame ? 'Bringing: ' + (g.game || 'a surprise game') : '',
    g.message ? 'Note: “' + g.message + '”' : '',
    '', 'Totals: ' + totals_(guests),
    'Open your sheet: ' + ss_().getUrl(),
  ].filter(function (l, i, a) { return l !== '' || (i > 0 && a[i - 1] !== ''); });
  if (s.notifyOnRsvp) {
    var to = s.notifyEmail || ownerEmail_();
    if (to) {
      try {
        MailApp.sendEmail({ to: to, subject: (yes ? '💖 ' : '🥹 ') + headline + (isUpdate ? ' (updated)' : ''), body: headline + '.\n' + lines.join('\n'), name: s.eventName || 'RSVPs' });
        notifyStatus_('email', true);
      } catch (x) { notifyStatus_('email', false, String(x.message || x)); }
    }
  }
  if (s.pushOnRsvp && s.pushTopic) pushNtfy_(s.pushTopic, (s.eventName || 'RSVP') + ': ' + headline + (isUpdate ? ' (updated)' : ''), lines.filter(Boolean).slice(0, -1).join('\n'), yes ? 'heart' : 'pensive');
}

function pushNtfy_(topic, title, message, tag) {
  try {
    var r = UrlFetchApp.fetch('https://ntfy.sh', {
      method: 'post', contentType: 'application/json', muteHttpExceptions: true,
      payload: JSON.stringify({ topic: topic, title: title, message: message, tags: [tag || 'sparkles'], priority: 4 }),
    });
    var ok = r.getResponseCode() < 300;
    notifyStatus_('push', ok, ok ? '' : 'ntfy returned ' + r.getResponseCode());
    return ok;
  } catch (x) { notifyStatus_('push', false, String(x.message || x)); return false; }
}

// ───────────────────────────────────────── host actions
var SETTING_RULES = (function () {
  function str(max) { return function (v) { return typeof v === 'string' && v.length <= max ? v.trim() : undefined; }; }
  function re(rx) { return function (v) { return typeof v === 'string' && rx.test(v) ? v : undefined; }; }
  function bool(v) { return typeof v === 'boolean' ? v : undefined; }
  function int(lo, hi) { return function (v) { return typeof v === 'number' && Math.floor(v) === v && v >= lo && v <= hi ? v : undefined; }; }
  var LINK = /^$|^https:\/\/[^\s"'<>]{4,600}$/;
  return {
    eventName: str(80), hostName: str(60), tagline: str(120), celebrants: str(100),
    date: re(/^$|^\d{4}-\d{2}-\d{2}$/), time: re(/^$|^\d{2}:\d{2}$/), endTime: re(/^$|^\d{2}:\d{2}$/),
    timezone: function (v) { try { Utilities.formatDate(new Date(), v, 'yyyy'); return typeof v === 'string' && v ? v : undefined; } catch (x) { return undefined; } },
    venue: str(60), area: str(120), address: str(300), mapsUrl: re(LINK),
    rsvpDeadline: re(/^$|^\d{4}-\d{2}-\d{2}$/), allowLate: bool, hideAddress: bool, openInvite: bool,
    openMaxParty: int(1, 10), defaultMaxParty: int(1, 10), capacity: int(0, 1000), musicUrl: re(LINK),
    notifyEmail: re(/^$|^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/), notifyOnRsvp: bool, pushTopic: re(/^$|^[A-Za-z0-9_-]{6,64}$/), pushOnRsvp: bool,
    moodboard: function (v) {
      if (!Array.isArray(v) || v.length < 1 || v.length > 6) return undefined;
      var bad = false;
      var out = v.map(function (m) {
        m = m || {};
        var src = typeof m.src === 'string' && (LINK.test(m.src) || /^photos\/[\w.-]{1,80}$/.test(m.src)) ? m.src : null; // web link, or a photo in the website's photos folder
        if (src === null) bad = true;
        return { src: src || '', caption: typeof m.caption === 'string' ? m.caption.trim().slice(0, 40) : '', note: typeof m.note === 'string' ? m.note.trim().slice(0, 80) : '' };
      });
      return bad ? undefined : out;
    },
    amp: function (v) {
      if (!v || typeof v !== 'object') return undefined;
      var cur = readSettings_().amp;
      function num(n, lo, hi, d) { return typeof n === 'number' && isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n * 10) / 10)) : d; }
      return {
        text: typeof v.text === 'string' && v.text.trim() ? v.text.trim().slice(0, 12) : cur.text,
        x: num(v.x, 0, 100, cur.x), y: num(v.y, 0, 100, cur.y), size: num(v.size, 6, 60, cur.size),
        color: ['canvas', 'ivory', 'pink', 'burgundy'].indexOf(v.color) > -1 ? v.color : cur.color,
        show: typeof v.show === 'boolean' ? v.show : cur.show,
      };
    },
    texts: function (v) {
      if (!v || typeof v !== 'object') return undefined;
      var cur = readSettings_().texts;
      Object.keys(DEFAULT_SETTINGS.texts).forEach(function (k) { if (typeof v[k] === 'string') cur[k] = v[k].trim().slice(0, 90) || ' '; });
      return cur;
    },
  };
})();

function hostState_() {
  var props = PropertiesService.getScriptProperties();
  var status = {};
  try { status = JSON.parse(props.getProperty('notifyStatus') || '{}'); } catch (x) { status = {}; }
  var log = [];
  var sh = sheet_(SHEET.responses, RESPONSE_HEADERS);
  var last = sh.getLastRow();
  if (last > 1) {
    var n = Math.min(25, last - 1);
    sh.getRange(last - n + 1, 1, n, RESPONSE_HEADERS.length).getValues().reverse().forEach(function (r) {
      if (r[7] === 'test') return;
      var st = r[2] === STATUS_LABEL.attending ? 'attending' : r[2] === STATUS_LABEL.declined ? 'declined' : 'pending';
      log.push({ name: String(r[1]), status: st, partySize: Number(r[3]) || 0, at: asText_(r[0]) });
    });
  }
  return {
    settings: readSettings_(),
    guests: readGuests_().map(function (g) { var o = merge_(g, {}); delete o._row; delete o.contactNorm; delete o.lastRequestId; return o; }),
    log: log,
    notifyStatus: status,
    ownerEmail: ownerEmail_(),
    sheetUrl: ss_().getUrl(),
  };
}

function actionSaveSettings_(p) {
  var patch = p.patch || {};
  var clean = {}, bad = [];
  Object.keys(patch).forEach(function (k) {
    if (!(k in SETTING_RULES)) return;
    var v = SETTING_RULES[k](patch[k]);
    if (v === undefined) bad.push(k); else clean[k] = v;
  });
  if (bad.length) fail_(422, 'Please check: ' + bad.join(', ') + '.');
  withLock_(function () { writeSettings_(clean); });
  return hostState_();
}

function guestInput_(b, s, partial) {
  var out = {};
  if (!partial || 'name' in b) {
    var name = cleanText_(b.name, 80);
    if (!name) fail_(422, 'Each guest needs a name.');
    out.name = name;
  }
  if (!partial || 'contact' in b) {
    var c = parseContact_(cleanText_(b.contact, 120));
    if (c.kind === 'invalid') fail_(422, '“' + c.value + '” isn’t a valid phone number or email.');
    out.contact = c.value; out.contactNorm = c.norm;
  }
  if (!partial || 'maxParty' in b) {
    var m = b.maxParty === undefined || b.maxParty === '' || b.maxParty === null ? s.defaultMaxParty : Number(b.maxParty);
    if (!(m >= 1 && m <= 10 && Math.floor(m) === m)) fail_(422, 'Party size must be between 1 and 10.');
    out.maxParty = m;
  }
  if ('note' in b) out.hostNote = cleanText_(b.note, 200);
  return out;
}

function findGuest_(id) {
  var g = null;
  readGuests_().forEach(function (x) { if (x.id === String(id)) g = x; });
  if (!g) fail_(404, 'Guest not found.');
  return g;
}

function actionAddGuests_(p) {
  var list = Array.isArray(p.guests) ? p.guests : [];
  if (!list.length || list.length > 200) fail_(422, 'Add between 1 and 200 guests at a time.');
  var s = readSettings_();
  var prepared = list.map(function (g) { return guestInput_(g || {}, s, false); });
  withLock_(function () { prepared.forEach(function (g) { writeGuest_(newGuest_(g)); }); });
  return hostState_();
}

function actionUpdateGuest_(p) {
  withLock_(function () {
    var g = findGuest_(p.id);
    var s = readSettings_();
    var patch = guestInput_(p, s, true);
    var before = g.status;
    Object.keys(patch).forEach(function (k) { g[k] = patch[k]; });
    if ('status' in p) {
      if (['pending', 'attending', 'declined'].indexOf(p.status) === -1) fail_(422, 'Unknown status.');
      g.status = p.status;
      g.partySize = p.status === 'attending' ? Math.min(Math.max(Number(p.partySize) || g.partySize || 1, 1), g.maxParty) : 0;
      if (p.status === 'pending') { g.bringingGame = false; g.game = ''; g.respondedAt = ''; }
      else if (!g.respondedAt) g.respondedAt = new Date().toISOString();
    }
    writeGuest_(g);
    if (before !== g.status) logResponse_(g, true);
  });
  return hostState_();
}

function actionDeleteGuest_(p) {
  withLock_(function () { var g = findGuest_(p.id); guestSheet_().deleteRow(g._row); });
  return hostState_();
}

function actionNewToken_(p) {
  withLock_(function () { var g = findGuest_(p.id); g.token = newToken_(); writeGuest_(g); });
  return hostState_();
}

function actionUpload_(p) {
  var mime = String(p.mime || '');
  if (['image/jpeg', 'image/png', 'image/webp'].indexOf(mime) === -1) fail_(415, 'Upload a JPG, PNG or WebP photo.');
  var data = String(p.data || '');
  if (!data || data.length > 8 * 1024 * 1024) fail_(413, 'That photo is too large.');
  var bytes = Utilities.base64Decode(data);
  var folders = DriveApp.getFoldersByName('Two of a Kind · invitation photos');
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder('Two of a Kind · invitation photos');
  var file = folder.createFile(Utilities.newBlob(bytes, mime, 'photo-' + Date.now() + '.' + mime.split('/')[1]));
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return { url: 'https://lh3.googleusercontent.com/d/' + file.getId() };
}

function actionRemind_(p) {
  var s = readSettings_();
  var base = cleanText_(p.base, 300);
  var result = { sent: 0, noEmail: 0, recent: 0, failed: [] };
  readGuests_().forEach(function (g) {
    if (g.status !== 'pending') return;
    if (parseContact_(g.contact).kind !== 'email') { result.noEmail++; return; }
    if (g.remindedAt && Date.now() - Date.parse(g.remindedAt) < 20 * 3600e3) { result.recent++; return; }
    try {
      var first = g.name.split(' ')[0];
      var deadline = deadlineLabel_(s);
      MailApp.sendEmail({
        to: g.contact, name: s.hostName || s.eventName,
        subject: 'A little reminder: ' + (s.eventName || 'our celebration') + ' 💌',
        body: 'Hi ' + first + '!\n\nYour invitation to ' + (s.eventName || 'our celebration') + ' is still waiting to be opened.' +
          (deadline ? ' Please RSVP by ' + deadline + '.' : '') + '\n\n' + base + '?g=' + g.token + '\n\n' + (s.hostName ? '— ' + s.hostName : ''),
      });
      g.remindedAt = new Date().toISOString();
      withLock_(function () { writeGuest_(g); });
      result.sent++;
    } catch (x) { result.failed.push({ name: g.name, error: String(x.message || x) }); }
  });
  return { result: result, state: hostState_() };
}

function actionTestNotify_(p) {
  var s = readSettings_();
  if (p.channel === 'push') {
    if (!s.pushTopic) fail_(422, 'Turn on phone notifications first.');
    if (!pushNtfy_(s.pushTopic, (s.eventName || 'Your invitation') + ' 💌', 'Notifications are working. You’ll get one like this every time someone RSVPs.', 'sparkles')) {
      fail_(502, 'Couldn’t reach ntfy. Try again in a minute.');
    }
  } else {
    var to = s.notifyEmail || ownerEmail_();
    if (!to) fail_(422, 'Add your email address first.');
    try {
      MailApp.sendEmail({ to: to, subject: 'Test from your invitation ✨', body: 'RSVP emails are working. You’ll get one like this whenever a guest replies.\n\nYour sheet: ' + ss_().getUrl(), name: s.eventName || 'RSVPs' });
      notifyStatus_('email', true);
    } catch (x) { notifyStatus_('email', false, String(x.message || x)); fail_(502, 'Couldn’t send the email: ' + (x.message || x)); }
  }
  return { ok: true, state: hostState_() };
}

/** Run this once from the editor (select "setup" → Run) if you want to check permissions before deploying. */
function setup() {
  sheet_(SHEET.responses, RESPONSE_HEADERS);
  guestSheet_();
  readSettings_();
  Logger.log('Ready. Sheet: ' + ss_().getUrl() + ' · emails go to ' + ownerEmail_());
}
