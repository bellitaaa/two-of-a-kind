# Two of a Kind · free invitation website

Everything here is free: the website runs on GitHub Pages and the RSVPs, guest list and emails run on a
Google Apps Script attached to your own Google Sheet.

- `website/` → upload the contents of this folder to a GitHub repository named `two-of-a-kind` and turn on GitHub Pages. Include the `photos` folder: it holds the Polaroid pictures you added in the preview (drag the whole folder in, so the pictures stay inside `photos/`).
- `google-script/Code.gs` → paste into your Google Sheet's Apps Script editor, set `HOST_PASSWORD`, and deploy it as a Web app.
- Then paste the Web app URL into `website/config.js`.

Follow the step-by-step "Two of a Kind: Go-Live Guide" from our chat.

Your links once it's live:
- Invitation (send this to everyone): `https://YOUR-GITHUB-NAME.github.io/two-of-a-kind/`
- Host dashboard: `https://YOUR-GITHUB-NAME.github.io/two-of-a-kind/host.html`
